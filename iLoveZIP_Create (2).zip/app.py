from flask import Flask, render_template, request
import requests
from config import API_KEY

app = Flask(__name__)

BASE_URL = "https://api.openweathermap.org/data/2.5/weather"


@app.route("/", methods=["GET", "POST"])
def home():

    weather = None

    if request.method == "POST":

        city = request.form.get("city")

        params = {
            "q": city,
            "appid": API_KEY,
            "units": "metric"
        }

        try:
            response = requests.get(BASE_URL, params=params)
            data = response.json()

            # Print response for debugging
            print("Status Code:", response.status_code)
            print("Response:", data)

            if response.status_code == 200:

                weather = {
                    "city": data["name"],
                    "country": data["sys"]["country"],
                    "temperature": data["main"]["temp"],
                    "humidity": data["main"]["humidity"],
                    "wind": data["wind"]["speed"],
                    "description": data["weather"][0]["description"].title()
                }

            else:
                weather = {
                    "error": data.get("message", "Something went wrong")
                }

        except Exception as e:
            weather = {
                "error": str(e)
            }

    return render_template("index.html", weather=weather)


if __name__ == "__main__":
    app.run(debug=True)